//
//  AddViewController.swift
//  Table
//
//  Created by 203a18 on 2022/05/13.
//

import UIKit

class AddViewController: UIViewController {
    
    @IBOutlet var tfAddItem: UITextField!
    @IBOutlet var AddTextView: UITextView!

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnAddItem(_ sender: UIButton) {
        items.append(tfAddItem.text!)
        itemsImageFile.append("clock.png")
        tfAddItem.text=""
        
        performSegue(withIdentifier: "goToSecond", sender: sender)
        
        _ = navigationController?.popViewController(animated: true)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goToSecond"{
            let vc = segue.destination as! DetailViewController
            vc.labelString = "data"
        }
    }
    
}
